function search(nameList, searchTerm) {
  let wordsThatMatch = nameList.filter((word) =>
    word.toUpperCase().includes(searchTerm.toUpperCase())
  );
  return wordsThatMatch;
}
