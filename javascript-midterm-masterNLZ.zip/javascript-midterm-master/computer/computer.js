class Computer {
  constructor(make, model, driveCapacity) {
    this.make = make;
    this.model = model;
    this.driveCapacity = "500GB";
    this.batteryPercent = 100;
    this.status = false;
  }

  getBatteryPercent() {
    return this.batteryPercent + "%";
  }
  // should return a string value of the batteryPercent property followed by a percent symbol

  getStatus() {
    return this.status ? "ON" : "OFF";
  }

  //should return the string value of the status property, 'ON' if the computer is on, 'OFF' if the computer is off
}
