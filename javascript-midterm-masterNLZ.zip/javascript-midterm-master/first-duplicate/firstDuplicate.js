function firstDuplicate(array) {
  //where to store duplicates
  let duplicates = new Set();

  //since it's an array, we can to cheack if  each item has the num(duplicate) that we're looking for
  for (let num of array) {
    if (duplicates.has(num)) {
      //if it does, return that duplicate number
      return num;
    }
    //add the duplicate numbers to a new set of numbers
    duplicates.add(num);
  }
  //if no duplicates, return -1
  return -1;
}
